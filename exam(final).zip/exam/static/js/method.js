var method = function () {
  return {
    a: function () {
      console.log(1);
    }
  }
}
