require('normalize.css');
require('./static/css/index.scss');
// 主要交互逻辑部分
require('./static/js/index.js');
